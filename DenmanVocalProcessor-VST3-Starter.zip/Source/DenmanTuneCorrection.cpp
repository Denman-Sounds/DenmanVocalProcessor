#include <JuceHeader.h>

class DenmanTuneCorrectionAudioProcessor : public juce::AudioProcessor
{
public:
    DenmanTuneCorrectionAudioProcessor()
        : AudioProcessor(BusesProperties().withInput("Input", juce::AudioChannelSet::stereo(), true)
                                      .withOutput("Output", juce::AudioChannelSet::stereo(), true)),
          amount(*this, nullptr, "PARAMS", {
              std::make_unique<juce::AudioParameterFloat>("amount", "Correction", 0.0f, 100.0f, 80.0f)
          }) {}

    const juce::String getName() const override { return "Denman Tune Correction"; }
    bool acceptsMidi() const override { return false; }
    bool producesMidi() const override { return false; }
    bool isMidiEffect() const override { return false; }
    double getTailLengthSeconds() const override { return 0.0; }
    int getNumPrograms() override { return 1; }
    int getCurrentProgram() override { return 0; }
    void setCurrentProgram(int) override {}
    const juce::String getProgramName(int) override { return {}; }
    void changeProgramName(int, const juce::String&) override {}
    bool hasEditor() const override { return true; }

    void prepareToPlay(double, int) override {}
    void releaseResources() override {}
    bool isBusesLayoutSupported(const BusesLayout& layouts) const override
    {
        return layouts.getMainInputChannelSet() == juce::AudioChannelSet::mono()
            || layouts.getMainInputChannelSet() == juce::AudioChannelSet::stereo();
    }

    void processBlock(juce::AudioBuffer<float>& buffer, juce::MidiBuffer&) override
    {
        juce::ScopedNoDenormals noDenormals;
        // Starter build: clean pass-through. The pitch-detection/retuning engine
        // will be added next without changing the plugin name or project structure.
        juce::ignoreUnused(buffer);
    }

    juce::AudioProcessorEditor* createEditor() override
    {
        return new Editor(*this);
    }

    void getStateInformation(juce::MemoryBlock& destData) override
    {
        auto state = amount.copyState();
        if (auto xml = state.createXml())
            copyXmlToBinary(*xml, destData);
    }

    void setStateInformation(const void* data, int sizeInBytes) override
    {
        if (auto xml = getXmlFromBinary(data, sizeInBytes))
            amount.replaceState(juce::ValueTree::fromXml(*xml));
    }

private:
    class Editor : public juce::AudioProcessorEditor
    {
    public:
        Editor(DenmanTuneCorrectionAudioProcessor& p) : AudioProcessorEditor(&p), processor(p)
        {
            title.setText("DENMAN TUNE CORRECTION", juce::dontSendNotification);
            title.setFont(juce::Font(24.0f, juce::Font::bold));
            title.setJustificationType(juce::Justification::centred);
            addAndMakeVisible(title);

            amount.setSliderStyle(juce::Slider::RotaryHorizontalVerticalDrag);
            amount.setTextBoxStyle(juce::Slider::TextBoxBelow, false, 100, 25);
            amount.setRange(0.0, 100.0, 0.1);
            amount.setValue(80.0);
            addAndMakeVisible(amount);

            label.setText("Correction Amount", juce::dontSendNotification);
            label.setJustificationType(juce::Justification::centred);
            addAndMakeVisible(label);
            setSize(420, 280);
        }

        void paint(juce::Graphics& g) override { g.fillAll(juce::Colours::black); }
        void resized() override
        {
            title.setBounds(10, 15, getWidth()-20, 40);
            amount.setBounds(110, 75, 200, 150);
            label.setBounds(110, 225, 200, 25);
        }
    private:
        DenmanTuneCorrectionAudioProcessor& processor;
        juce::Label title, label;
        juce::Slider amount;
    };

    juce::AudioProcessorValueTreeState amount;
};

juce::AudioProcessor* JUCE_CALLTYPE createPluginFilter()
{
    return new DenmanTuneCorrectionAudioProcessor();
}
