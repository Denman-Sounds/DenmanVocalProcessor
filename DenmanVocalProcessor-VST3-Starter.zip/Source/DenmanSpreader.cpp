#include <JuceHeader.h>

class DenmanSpreaderAudioProcessor : public juce::AudioProcessor
{
public:
    DenmanSpreaderAudioProcessor()
        : AudioProcessor(BusesProperties().withInput("Input", juce::AudioChannelSet::stereo(), true)
                                      .withOutput("Output", juce::AudioChannelSet::stereo(), true)),
          apvts(*this, nullptr, "PARAMS", createParameters()) {}

    const juce::String getName() const override { return "Denman Spreader"; }
    bool acceptsMidi() const override { return false; }
    bool producesMidi() const override { return false; }
    bool isMidiEffect() const override { return false; }
    double getTailLengthSeconds() const override { return 0.0; }
    int getNumPrograms() override { return 1; }
    int getCurrentProgram() override { return 0; }
    void setCurrentProgram(int) override {}
    const juce::String getProgramName(int) override { return {}; }
    void changeProgramName(int, const juce::String&) override {}
    bool hasEditor() const override { return true; }

    void prepareToPlay(double sampleRate, int samplesPerBlock) override
    {
        widener.prepare({sampleRate, (juce::uint32)samplesPerBlock, 2});
    }
    void releaseResources() override { widener.reset(); }

    bool isBusesLayoutSupported(const BusesLayout& layouts) const override
    {
        return layouts.getMainInputChannelSet() == juce::AudioChannelSet::stereo();
    }

    void processBlock(juce::AudioBuffer<float>& buffer, juce::MidiBuffer&) override
    {
        juce::dsp::AudioBlock<float> block(buffer);
        widener.setWidth(apvts.getRawParameterValue("width")->load());
        widener.process(juce::dsp::ProcessContextReplacing<float>(block));
    }

    juce::AudioProcessorEditor* createEditor() override
    {
        return new Editor(*this);
    }

    void getStateInformation(juce::MemoryBlock& destData) override
    {
        if (auto xml = apvts.copyState().createXml()) copyXmlToBinary(*xml, destData);
    }

    void setStateInformation(const void* data, int sizeInBytes) override
    {
        if (auto xml = getXmlFromBinary(data, sizeInBytes))
            apvts.replaceState(juce::ValueTree::fromXml(*xml));
    }

private:
    static juce::AudioProcessorValueTreeState::ParameterLayout createParameters()
    {
        juce::AudioProcessorValueTreeState::ParameterLayout p;
        p.add(std::make_unique<juce::AudioParameterFloat>("width", "Width", 0.0f, 200.0f, 100.0f));
        return p;
    }

    class Editor : public juce::AudioProcessorEditor
    {
    public:
        Editor(DenmanSpreaderAudioProcessor& p) : AudioProcessorEditor(&p)
        {
            title.setText("DENMAN SPREADER", juce::dontSendNotification);
            title.setFont(juce::Font(24.0f, juce::Font::bold));
            title.setJustificationType(juce::Justification::centred);
            addAndMakeVisible(title);

            slider.setSliderStyle(juce::Slider::RotaryHorizontalVerticalDrag);
            slider.setRange(0.0, 200.0, 0.1);
            slider.setValue(100.0);
            slider.setTextBoxStyle(juce::Slider::TextBoxBelow, false, 100, 25);
            addAndMakeVisible(slider);

            label.setText("Width", juce::dontSendNotification);
            label.setJustificationType(juce::Justification::centred);
            addAndMakeVisible(label);
            setSize(420, 280);
        }

        void paint(juce::Graphics& g) override { g.fillAll(juce::Colours::black); }
        void resized() override
        {
            title.setBounds(10, 15, getWidth()-20, 40);
            slider.setBounds(110, 75, 200, 150);
            label.setBounds(110, 225, 200, 25);
        }
    private:
        juce::Label title, label;
        juce::Slider slider;
    };

    juce::AudioProcessorValueTreeState apvts;
    juce::dsp::StereoWidener<float> widener;
};

juce::AudioProcessor* JUCE_CALLTYPE createPluginFilter()
{
    return new DenmanSpreaderAudioProcessor();
}
