#include <JuceHeader.h>

class DenmanAirCompressorAudioProcessor : public juce::AudioProcessor
{
public:
    DenmanAirCompressorAudioProcessor()
        : AudioProcessor(BusesProperties().withInput("Input", juce::AudioChannelSet::stereo(), true)
                                      .withOutput("Output", juce::AudioChannelSet::stereo(), true)),
          apvts(*this, nullptr, "PARAMS", createParameters()) {}

    const juce::String getName() const override { return "Denman Air Compressor"; }
    bool acceptsMidi() const override { return false; }
    bool producesMidi() const override { return false; }
    bool isMidiEffect() const override { return false; }
    double getTailLengthSeconds() const override { return 0.0; }
    int getNumPrograms() override { return 1; }
    int getCurrentProgram() override { return 0; }
    void setCurrentProgram(int) override {}
    const juce::String getProgramName(int) override { return {}; }
    void changeProgramName(int, const juce::String&) override {}
    bool hasEditor() const override { return true; }

    void prepareToPlay(double sampleRate, int samplesPerBlock) override
    {
        compressor.prepare({sampleRate, (juce::uint32)samplesPerBlock, 2});
        compressor.setAttack(10.0f);
        compressor.setRelease(100.0f);
    }
    void releaseResources() override { compressor.reset(); }

    bool isBusesLayoutSupported(const BusesLayout& layouts) const override
    {
        return layouts.getMainInputChannelSet() == juce::AudioChannelSet::mono()
            || layouts.getMainInputChannelSet() == juce::AudioChannelSet::stereo();
    }

    void processBlock(juce::AudioBuffer<float>& buffer, juce::MidiBuffer&) override
    {
        compressor.setThreshold(apvts.getRawParameterValue("threshold")->load());
        compressor.setRatio(apvts.getRawParameterValue("ratio")->load());
        compressor.setAttack(apvts.getRawParameterValue("attack")->load());
        compressor.setRelease(apvts.getRawParameterValue("release")->load());
        juce::dsp::AudioBlock<float> block(buffer);
        compressor.process(juce::dsp::ProcessContextReplacing<float>(block));
    }

    juce::AudioProcessorEditor* createEditor() override { return new Editor(*this); }

    void getStateInformation(juce::MemoryBlock& destData) override
    {
        if (auto xml = apvts.copyState().createXml()) copyXmlToBinary(*xml, destData);
    }

    void setStateInformation(const void* data, int sizeInBytes) override
    {
        if (auto xml = getXmlFromBinary(data, sizeInBytes))
            apvts.replaceState(juce::ValueTree::fromXml(*xml));
    }

private:
    static juce::AudioProcessorValueTreeState::ParameterLayout createParameters()
    {
        juce::AudioProcessorValueTreeState::ParameterLayout p;
        p.add(std::make_unique<juce::AudioParameterFloat>("threshold", "Threshold", -60.0f, 0.0f, -18.0f));
        p.add(std::make_unique<juce::AudioParameterFloat>("ratio", "Ratio", 1.0f, 20.0f, 3.0f));
        p.add(std::make_unique<juce::AudioParameterFloat>("attack", "Attack", 0.1f, 100.0f, 10.0f));
        p.add(std::make_unique<juce::AudioParameterFloat>("release", "Release", 10.0f, 500.0f, 100.0f));
        return p;
    }

    class Editor : public juce::AudioProcessorEditor
    {
    public:
        Editor(DenmanAirCompressorAudioProcessor& p) : AudioProcessorEditor(&p)
        {
            title.setText("DENMAN AIR COMPRESSOR", juce::dontSendNotification);
            title.setFont(juce::Font(22.0f, juce::Font::bold));
            title.setJustificationType(juce::Justification::centred);
            addAndMakeVisible(title);

            const char* names[] = {"Threshold", "Ratio", "Attack", "Release"};
            for (int i = 0; i < 4; ++i)
            {
                sliders[i].setSliderStyle(juce::Slider::RotaryHorizontalVerticalDrag);
                sliders[i].setTextBoxStyle(juce::Slider::TextBoxBelow, false, 80, 22);
                addAndMakeVisible(sliders[i]);
                labels[i].setText(names[i], juce::dontSendNotification);
                labels[i].setJustificationType(juce::Justification::centred);
                addAndMakeVisible(labels[i]);
            }
            setSize(500, 330);
        }

        void paint(juce::Graphics& g) override { g.fillAll(juce::Colours::black); }
        void resized() override
        {
            title.setBounds(10, 12, getWidth()-20, 40);
            for (int i = 0; i < 4; ++i)
            {
                int x = 15 + i * 120;
                sliders[i].setBounds(x, 70, 105, 125);
                labels[i].setBounds(x, 200, 105, 25);
            }
        }
    private:
        juce::Label title;
        juce::Slider sliders[4];
        juce::Label labels[4];
    };

    juce::AudioProcessorValueTreeState apvts;
    juce::dsp::Compressor<float> compressor;
};

juce::AudioProcessor* JUCE_CALLTYPE createPluginFilter()
{
    return new DenmanAirCompressorAudioProcessor();
}
