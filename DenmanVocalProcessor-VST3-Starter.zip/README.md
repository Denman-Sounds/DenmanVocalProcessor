# DenmanVocalProcessor

Three branded VST3 starter plugins:

- Denman Tune Correction
- Denman Spreader
- Denman Air Compressor

The project uses JUCE through CMake FetchContent, so JUCE does not need to be manually cloned into the repository.

## Build

```bash
cmake -B build -DCMAKE_BUILD_TYPE=Release
cmake --build build --config Release
```

The Tune Correction plugin is currently a clean starter/pass-through engine with its control/UI in place. The pitch-detection and retuning engine will be added as the next development stage.
