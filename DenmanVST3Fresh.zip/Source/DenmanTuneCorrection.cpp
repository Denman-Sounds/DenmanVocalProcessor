#include <JuceHeader.h>
class DenmanTuneCorrectionAudioProcessor : public juce::AudioProcessor {
public:
 DenmanTuneCorrectionAudioProcessor():AudioProcessor(BusesProperties().withInput("Input",juce::AudioChannelSet::stereo(),true).withOutput("Output",juce::AudioChannelSet::stereo(),true)){}
 const juce::String getName()const override{return "Denman Tune Correction";}
 bool acceptsMidi()const override{return false;} bool producesMidi()const override{return false;} bool isMidiEffect()const override{return false;}
 double getTailLengthSeconds()const override{return 0.0;} int getNumPrograms()override{return 1;} int getCurrentProgram()override{return 0;} void setCurrentProgram(int)override{} const juce::String getProgramName(int)override{return {};} void changeProgramName(int,const juce::String&)override{} bool hasEditor()const override{return true;}
 void prepareToPlay(double,int)override{} void releaseResources()override{}
 bool isBusesLayoutSupported(const BusesLayout& b)const override{return b.getMainInputChannelSet()==b.getMainOutputChannelSet();}
 void processBlock(juce::AudioBuffer<float>&,juce::MidiBuffer&)override{}
 juce::AudioProcessorEditor* createEditor()override{return new Editor();}
 void getStateInformation(juce::MemoryBlock&)override{} void setStateInformation(const void*,int)override{}
 class Editor:public juce::AudioProcessorEditor{public:Editor(){setSize(420,280);}void paint(juce::Graphics&g)override{g.fillAll(juce::Colours::black);g.setColour(juce::Colours::white);g.setFont(22.0f);g.drawText("DENMAN TUNE CORRECTION",10,20,400,40,juce::Justification::centred);g.setFont(16.0f);g.drawText("Correction engine - next stage",10,120,400,40,juce::Justification::centred);}};
};
juce::AudioProcessor* JUCE_CALLTYPE createPluginFilter(){return new DenmanTuneCorrectionAudioProcessor();}
