#include <JuceHeader.h>
class DenmanAirCompressorAudioProcessor:public juce::AudioProcessor{
public:
 DenmanAirCompressorAudioProcessor():AudioProcessor(BusesProperties().withInput("Input",juce::AudioChannelSet::stereo(),true).withOutput("Output",juce::AudioChannelSet::stereo(),true)),compressor(){}
 const juce::String getName()const override{return "Denman Air Compressor";} bool acceptsMidi()const override{return false;} bool producesMidi()const override{return false;} bool isMidiEffect()const override{return false;} double getTailLengthSeconds()const override{return 0.0;} int getNumPrograms()override{return 1;} int getCurrentProgram()override{return 0;} void setCurrentProgram(int)override{} const juce::String getProgramName(int)override{return {};} void changeProgramName(int,const juce::String&)override{} bool hasEditor()const override{return true;}
 void prepareToPlay(double sr,int bs)override{compressor.prepare({sr,(juce::uint32)bs,2});compressor.setThreshold(-18.0f);compressor.setRatio(3.0f);compressor.setAttack(10.0f);compressor.setRelease(100.0f);} void releaseResources()override{compressor.reset();} bool isBusesLayoutSupported(const BusesLayout&b)const override{return b.getMainInputChannelSet()==b.getMainOutputChannelSet();} void processBlock(juce::AudioBuffer<float>&buffer,juce::MidiBuffer&)override{juce::dsp::AudioBlock<float> block(buffer);compressor.process(juce::dsp::ProcessContextReplacing<float>(block));}
 juce::AudioProcessorEditor*createEditor()override{return new Editor();} void getStateInformation(juce::MemoryBlock&)override{} void setStateInformation(const void*,int)override{}
 class Editor:public juce::AudioProcessorEditor{public:Editor(){setSize(460,280);}void paint(juce::Graphics&g)override{g.fillAll(juce::Colours::black);g.setColour(juce::Colours::white);g.setFont(21.0f);g.drawText("DENMAN AIR COMPRESSOR",10,20,440,40,juce::Justification::centred);}};
private:juce::dsp::Compressor<float> compressor;
};
juce::AudioProcessor*JUCE_CALLTYPE createPluginFilter(){return new DenmanAirCompressorAudioProcessor();}
