#include <JuceHeader.h>
class DenmanSpreaderAudioProcessor:public juce::AudioProcessor{
public:
 DenmanSpreaderAudioProcessor():AudioProcessor(BusesProperties().withInput("Input",juce::AudioChannelSet::stereo(),true).withOutput("Output",juce::AudioChannelSet::stereo(),true)){}
 const juce::String getName()const override{return "Denman Spreader";} bool acceptsMidi()const override{return false;} bool producesMidi()const override{return false;} bool isMidiEffect()const override{return false;} double getTailLengthSeconds()const override{return 0.0;} int getNumPrograms()override{return 1;} int getCurrentProgram()override{return 0;} void setCurrentProgram(int)override{} const juce::String getProgramName(int)override{return {};} void changeProgramName(int,const juce::String&)override{} bool hasEditor()const override{return true;}
 void prepareToPlay(double,int)override{} void releaseResources()override{} bool isBusesLayoutSupported(const BusesLayout&b)const override{return b.getMainInputChannelSet()==juce::AudioChannelSet::stereo()&&b.getMainOutputChannelSet()==juce::AudioChannelSet::stereo();} void processBlock(juce::AudioBuffer<float>&buffer,juce::MidiBuffer&)override{if(buffer.getNumChannels()>1){auto*l=buffer.getWritePointer(0);auto*r=buffer.getWritePointer(1);for(int i=0;i<buffer.getNumSamples();++i){float mid=(l[i]+r[i])*0.5f;float side=(l[i]-r[i])*0.5f*1.5f;l[i]=mid+side;r[i]=mid-side;}}}
 juce::AudioProcessorEditor*createEditor()override{return new Editor();} void getStateInformation(juce::MemoryBlock&)override{} void setStateInformation(const void*,int)override{}
 class Editor:public juce::AudioProcessorEditor{public:Editor(){setSize(420,280);}void paint(juce::Graphics&g)override{g.fillAll(juce::Colours::black);g.setColour(juce::Colours::white);g.setFont(24.0f);g.drawText("DENMAN SPREADER",10,20,400,40,juce::Justification::centred);}};
};
juce::AudioProcessor*JUCE_CALLTYPE createPluginFilter(){return new DenmanSpreaderAudioProcessor();}
